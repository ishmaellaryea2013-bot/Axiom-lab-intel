AXIOM LAB - WEBSITE + APP (ONE FILE)
====================================

index.html is EVERYTHING: the website with all the details, and the app inside it.
  - Open index.html  -> you see the website (details, subjects, features, how to install).
  - Press "Open Axiom Lab" -> the app opens.
  - Inside the app, the "Website" tab takes you back to the details page.
  - "Install app" and "Download" buttons are on the website AND inside the app.

Other files (keep them next to index.html):
  manifest.webmanifest   lets phones and computers install it as an app
  sw.js                  makes it work offline after the first visit
  icons/                 the app icons

WHY YOU DID NOT SEE "INSTALL APP" IN THE BROWSER MENU
  Browsers only offer "Install app" when the page is opened from a website
  address (starting with https://). Opening index.html from a folder or a zip
  can never show it. Put the files on GitHub Pages (below), open the https address,
  and the Install option appears.

PUT IT ON GITHUB PAGES (free)
  1. Sign up at https://github.com/signup
  2. Create a new PUBLIC repository named  axiom-lab  (https://github.com/new)
  3. Unzip this zip. Upload ALL the files and the icons folder (Add file > Upload files).
     If you uploaded an old app.html before, delete it.
  4. Click Commit changes.
  5. Settings > Pages > Branch: main, folder: / (root) > Save.
  6. After 1-2 minutes open:  https://YOURUSERNAME.github.io/axiom-lab/

INSTALL (after it is on its https address)
  Android Chrome : press "Install app" on the page, or menu > Install app
  iPhone Safari  : Share button > Add to Home Screen
  Computer       : install icon at the right of the address bar (Chrome or Edge)

DOWNLOAD
  The "Download" button saves a copy of index.html. Open that file any time, even
  without internet. (iPhone cannot save it this way. Use Add to Home Screen instead.)

NOTES
  - Progress, accounts and passwords stay on each person's own device.
  - Ewe has no audio. French audio needs a French voice on the device.
